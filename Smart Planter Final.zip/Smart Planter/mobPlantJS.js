﻿var coll = document.getElementsByClassName("collapsible");
var i;

        
//Taken from w3 schools page on collapsibles. https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_collapsible
for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var content = this.nextElementSibling;
        if (content.style.display === "flex") {
            content.style.display = "none";
        } else {
            content.style.display = "flex";
        }
    });
}