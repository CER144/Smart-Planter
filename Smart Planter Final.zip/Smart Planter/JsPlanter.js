﻿console.log("hello");


function pestScan() {
    console.log("clicked!")
    document.getElementById("loader").style.display = "block";
    document.getElementById("popup").style.display = "block";
    const myTimeout = setTimeout(endScan, 3000);
}



function endScan() {
    document.getElementById("loader").style.display = "none";
    document.getElementById("popup").style.display = "none";
    nextBox();
}

function nextBox() {
    document.getElementById("scanEnd").style.display = "block";
}

function showPests(){
    document.getElementById("pestAlert1").style.display = "block";
    document.getElementById("pestAlert2").style.display = "block";
}

function hideForm() {
    document.getElementById("addForm").style.display = "none";
}

function showForm() {
    document.getElementById("addForm").style.display = "inline-block";
}


var btn = document.getElementById("expand");
var mod = document.getElementById("modal");
var end = document.getElementById("close");
function expand(modal) {
    modal.nextElementSibling.style.display = "flex";
}
